from distutils.core import setup
from setuptools import setup, find_packages

setup(
    name='MetricsBuilder',
    version='',
    packages=find_packages(),
    url='',
    license='',
    author='sourabhkatti',
    author_email='',
    description='',

    install_requires=['requests']
)
