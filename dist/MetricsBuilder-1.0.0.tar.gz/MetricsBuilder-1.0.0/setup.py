from distutils.core import setup
from setuptools import setup, find_packages

setup(
    name='MetricsBuilder',
    version='1.0.0',
    packages=find_packages(),
    url='',
    license='',
    author='sourabhkatti',
    author_email='',
    description='',

    install_requires=['requests']
)
